#include <stdio.h>
#include <cs50.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

int main (void)
{
    
    
string s = get_string();

#define IN_WORD 1
#define OUT_OF_WORD 0

int status = IN_WORD;

int print_this;

if (s[0] != ' ')
{
    print_this = s[0];
    print_this = toupper (print_this);
    printf("%c", print_this);
}

for (int i = 0; n = strlen(s); i<= n;  i++)
    {
      
        
        if (s[i] == ' ')
        {
            status = OUT_OF_WORD;
        }
        else if (status == OUT_OF_WORD)
        {
            status = IN_WORD;
            print_this = s[i];
            print_this = toupper (print_this);
            printf("%c", print_this);
        }
        
    }

printf("\n");

}